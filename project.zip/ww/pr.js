const express = require('express');
const OpenAI = require('openai');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(express.json());
app.use(cors());

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'QWERTY',
  password: 'VIP1320526',
  port: 5432,
});

const openai = new OpenAI({
  apiKey: "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"
});

app.post('/getResponse', async (req, res) => {
  const { code, exerciseId } = req.body;

  // Получаем текст задачи из базы данных по exerciseId
  try {
    const exerciseQuery = await pool.query('SELECT "Contents" FROM "Exercises" WHERE "Id" = $1', [exerciseId]);
    const exerciseContents = exerciseQuery.rows[0].Contents;

    console.log(exerciseContents);
    const tools = [
      {
        type: "function",
        function: {
          name: "get_answer_rating",
          description: "rates answer",
          parameters: {
            type: "object",
            properties: {
              readability: {
                type: "integer",
                description: "readability of the code",
              },
              complexity: {
                type: "integer",
                description: "complexity of the code",
              },
              creativity: {
                type: "integer",
                description: "creativity of the code",
              },
              efficiency: {
                type: "integer",
                description: "efficiency of the code",
              },
              structure: {
                type: "integer",
                description: "structure of the code",
              },
              logic: {
                type: "integer",
                description: "logic of the code",
              },
            },
            required: ["readability", "complexity", "creativity", "efficiency", "structure", "logic"],
          },
        },
      },
    ];

    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [{ "role": "system", "content": `Evaluate the code for exercise ${exerciseId}: ${exerciseContents} on these six criteria from 1 to 10: readability, complexity, creativity, efficiency, structure, logic. Here's what each of the criteria means:
      readability: This criterion evaluates how easy the code is to read and understand. Readability is related to the use of clear and informative variable names (CamelCase, snake_case, etc.) and functions, good code formatting (indentation, spaces, line breaks), and comments that explain what each part of the code does;
      complexity: This criterion is responsible for how difficult the code is written, maybe it was possible to shorten some part of the code, convert some lines into one. (the higher the score, the easier the code is written);
      creativity: This criterion assesses the user's ability to solve a problem using non-standard or inventive approaches. It includes the ability to apply creative solution methods as well as the use of different programming patterns;
      efficiency: This criterion refers to how well and how fast the code executes. This includes using optimal algorithms and data structures to achieve a goal, minimising execution time and resource usage (such as memory or CPU time);
      structure: This criterion evaluates the organisation and structure of the code. It includes the use of modularity and the division of code into logical blocks, compliance with DRY (Don't Repeat Yourself) principles, and the presence of a clear plan or algorithm for solving the problem;
      logic: This criterion evaluates the logical consistency and correctness of algorithms and solutions. It takes into account the correctness of logical operations, exception handling, condition checking and the overall logic of programme execution.` },
      { "role": "user", "content": code }],
      tools: tools,
      tool_choice: { "type": "function", "function": { "name": "get_answer_rating" } }
    });

    res.send(response.choices[0].message.tool_calls[0].function.arguments);
  } catch (error) {
    console.error('Error executing query', error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(3000, () => {
  console.log("Server is running");
});
